<?php return array('dependencies' => array(), 'version' => '38f2dd33c6d6a0814d27');
