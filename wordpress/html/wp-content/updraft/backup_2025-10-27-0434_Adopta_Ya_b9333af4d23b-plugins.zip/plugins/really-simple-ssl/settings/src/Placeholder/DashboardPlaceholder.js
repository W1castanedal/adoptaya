const DashboardPlaceholder = (props) => {
    return (
        <>
            <div className="rsssl-grid-item rsssl-column-2 rsssl-dashboard-placeholder"></div>
            <div className="rsssl-grid-item rsssl-row-2 rsssl-dashboard-placeholder"></div>
            <div className="rsssl-grid-item rsssl-row-2 rsssl-dashboard-placeholder"></div>
        </>
            );
}

export default DashboardPlaceholder;

