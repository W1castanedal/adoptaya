<?php
/**
 * Test file for Really Simple Security to check if uploads directory has code execution permissions
 *
 */

echo "RSSSL CODE EXECUTION MARKER";
